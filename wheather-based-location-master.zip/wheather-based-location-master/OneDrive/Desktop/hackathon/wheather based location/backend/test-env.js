require('dotenv').config();

console.log('GEOAPIFY_API_KEY:', process.env.GEOAPIFY_API_KEY);
console.log('OPENWEATHER_API_KEY:', process.env.OPENWEATHER_API_KEY);